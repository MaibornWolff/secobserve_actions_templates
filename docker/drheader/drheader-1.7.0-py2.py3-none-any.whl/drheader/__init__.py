# -*- coding: utf-8 -*-

"""Top-level package for drHEADer core."""

__version__ = '1.7.0'

from drheader.core import Drheader  # noqa
